import xbmcaddon

MainBase = 'https://cld.pt/dl/download/6b8d6732-50ee-4f58-aef9-3a54ac88706e/ListaPrincipal.xml'
#MainBase1 = 'https://cld.pt/dl/download/2c41d123-2876-4829-8a18-0c14d742e32a/play.html'
