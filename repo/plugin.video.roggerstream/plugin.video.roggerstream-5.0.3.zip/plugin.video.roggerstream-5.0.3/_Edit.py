import xbmcaddon

MainBase = 'http://pastebin.com/raw/iVUQtRws'
addon = xbmcaddon.Addon('plugin.video.roggerstream')